export type ActionPadMessages = {
  expand: string;
  collapse: string;
  expandLabel: string;
  collapseLabel: string;
};
