export type FlowItemMessages = {
  back: string;
  close: string;
  options: string;
};
