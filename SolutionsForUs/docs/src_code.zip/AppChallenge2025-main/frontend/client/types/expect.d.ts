import 'jest-extended';

declare const expect: (R, T?) => jest.Matchers<R, T>;